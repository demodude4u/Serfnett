/**
 * $Id: mxPointPair.java,v 1.1 2012/11/15 13:26:47 gaudenz Exp $
 * Copyright (c) 2008, Gaudenz Alder
 */
package com.mxgraph.layout.orthogonal.model;

/**
 *
 */
public class mxPointPair
{

}
